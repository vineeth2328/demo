
export CORE_PEER_TLS_ENABLED=true
export ORDERER_CA=${PWD}/artifacts/channel/crypto-config/ordererOrganizations/orderer/orderers/orderer0.orderer/msp/tlscacerts/tlsca.orderer-cert.pem
export PEER0_vanguard_CA=${PWD}/artifacts/channel/crypto-config/peerOrganizations/vanguard/tlsca/tlsca.vanguard-cert.pem
export PEER1_vanguard_CA=${PWD}/artifacts/channel/crypto-config/peerOrganizations/vanguard/tlsca/tlsca.vanguard-cert.pem
export PEER0_jpmorgan_CA=${PWD}/artifacts/channel/crypto-config/peerOrganizations/jpmorgan/tlsca/tlsca.jpmorgan-cert.pem
export PEER1_jpmorgan_CA=${PWD}/artifacts/channel/crypto-config/peerOrganizations/jpmorgan/tlsca/tlsca.jpmorgan-cert.pem
export PEER0_statestreet_CA=${PWD}/artifacts/channel/crypto-config/peerOrganizations/statestreet/tlsca/tlsca.statestreet-cert.pem
export PEER1_statestreet_CA=${PWD}/artifacts/channel/crypto-config/peerOrganizations/statestreet/tlsca/tlsca.statestreet-cert.pem
export FABRIC_CFG_PATH=${PWD}/channel-artifacts/

export CHANNEL_NAME=vgchannel

setGlobalsForOrderer() {
    sleep 1
    export CORE_PEER_LOCALMSPID="OrdererMSP"
    export CORE_PEER_TLS_ROOTCERT_FILE=${PWD}/artifacts/channel/crypto-config/ordererOrganizations/orderer/orderers/orderer0.orderer/msp/tlscacerts/tlsca.-cert.pem
    export CORE_PEER_MSPCONFIGPATH=${PWD}/artifacts/channel/crypto-config/ordererOrganizations/orderer/users/Admin@orderer/msp

}

setGlobalsForPeer0vanguard() {
    sleep 1
    export CORE_PEER_LOCALMSPID="vanguardMSP"
    export CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_vanguard_CA
    export CORE_PEER_MSPCONFIGPATH=${PWD}/artifacts/channel/crypto-config/peerOrganizations/vanguard/users/Admin@vanguard/msp
    export CORE_PEER_ADDRESS=peer0-vanguard:7051
}
setGlobalsForPeer1vanguard() {
    sleep 1
    export CORE_PEER_LOCALMSPID="vanguardMSP"
    export CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_vanguard_CA
    export CORE_PEER_MSPCONFIGPATH=${PWD}/artifacts/channel/crypto-config/peerOrganizations/vanguard/users/Admin@vanguard/msp
    export CORE_PEER_ADDRESS=peer1-vanguard:7051
}

setGlobalsForvanguard() {
    sleep 1
    export CORE_PEER_LOCALMSPID="vanguardMSP"
    export CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_vanguard_CA
    export CORE_PEER_MSPCONFIGPATH=${PWD}/artifacts/channel/crypto-config/peerOrganizations/vanguard/users/User1@vanguard/msp
    export CORE_PEER_ADDRESS=peer0-vanguard:7051
}

setGlobalsForPeer0jpmorgan() {
    sleep 1
    export CORE_PEER_LOCALMSPID="jpmorganMSP"
    export CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_jpmorgan_CA
    export CORE_PEER_MSPCONFIGPATH=${PWD}/artifacts/channel/crypto-config/peerOrganizations/jpmorgan/users/Admin@jpmorgan/msp
    export CORE_PEER_ADDRESS=peer0-jpmorgan:7051

}
setGlobalsForPeer1jpmorgan() {
    sleep 1
    export CORE_PEER_LOCALMSPID="jpmorganMSP"
    export CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_jpmorgan_CA
    export CORE_PEER_MSPCONFIGPATH=${PWD}/artifacts/channel/crypto-config/peerOrganizations/jpmorgan/users/Admin@jpmorgan/msp
    export CORE_PEER_ADDRESS=peer1-jpmorgan:7051

}
setGlobalsForPeer0statestreet() {
    sleep 1
    export CORE_PEER_LOCALMSPID="statestreetMSP"
    export CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_statestreet_CA
    export CORE_PEER_MSPCONFIGPATH=${PWD}/artifacts/channel/crypto-config/peerOrganizations/statestreet/users/Admin@statestreet/msp
    export CORE_PEER_ADDRESS=peer0-statestreet:7051

}
setGlobalsForPeer1statestreet() {
    sleep 1
    export CORE_PEER_LOCALMSPID="statestreetMSP"
    export CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_statestreet_CA
    export CORE_PEER_MSPCONFIGPATH=${PWD}/artifacts/channel/crypto-config/peerOrganizations/statestreet/users/Admin@statestreet/msp
    export CORE_PEER_ADDRESS=peer1-statestreet:7051

}




# presetup

export CHANNEL_NAME="vgchannel"
export CC_RUNTIME_LANGUAGE="node"
export VERSION="1"
export SEQUENCE="1"
export CC_SRC_PATH="/opt/gopath/src/github.com/hyperledger/fabric-samples/chaincode/node"
export CC_NAME="vanguard_cc"

packageChaincode() {
    rm -rf ${CC_NAME}.tar.gz
    setGlobalsForPeer0vanguard
    sleep 5
    peer lifecycle chaincode package ${CC_NAME}.tar.gz --path ${CC_SRC_PATH} --lang ${CC_RUNTIME_LANGUAGE} --label ${CC_NAME}_${VERSION}
    echo "===================== Chaincode is packaged ===================== "
}
# packageChaincode


installchaincodepeer0vanguard(){
    setGlobalsForPeer0vanguard
    sleep 10
    peer lifecycle chaincode install ${CC_NAME}.tar.gz
    
    
    }
installchaincodepeer1vanguard(){
    setGlobalsForPeer1vanguard
    sleep 10
    peer lifecycle chaincode install ${CC_NAME}.tar.gz
    sleep 10
    peer lifecycle chaincode install ${CC_NAME}.tar.gz
    echo "===================== Chaincode is installed on peer0.vanguard ===================== "
}
installchaincodepeer0jpmorgan(){
    setGlobalsForPeer0jpmorgan
    sleep 10
    peer lifecycle chaincode install ${CC_NAME}.tar.gz

    echo "===================== Chaincode is installed on peer0.jpmorgan ===================== "
}

installchaincodepeer1jpmorgan(){
    setGlobalsForPeer1jpmorgan
    sleep 10
    peer lifecycle chaincode install ${CC_NAME}.tar.gz

    echo "===================== Chaincode is installed on peer1.jpmorgan ===================== "
}

installchaincodepeer0statestreet(){
    setGlobalsForPeer0statestreet
    sleep 10
    peer lifecycle chaincode install ${CC_NAME}.tar.gz

    echo "===================== Chaincode is installed on peer0.statestreet ===================== "
}
installchaincodepeer1statestreet(){
    setGlobalsForPeer1statestreet
    sleep 10
    peer lifecycle chaincode install ${CC_NAME}.tar.gz

    echo "===================== Chaincode is installed on peer1.statestreet ===================== "
}
# installChaincode

queryInstalled() {
    setGlobalsForPeer0jpmorgan
    sleep 5
    peer lifecycle chaincode queryinstalled >&log.txt
    cat log.txt
    PACKAGE_ID=$(sed -n "/${CC_NAME}_${VERSION}/{s/^Package ID: //; s/, Label:.*$//; p;}" log.txt)
    echo PackageID is ${PACKAGE_ID}
    echo "===================== Query installed successful on peer0.vanguard on channel ===================== "
}

# queryInstalled

# --collections-config ./artifacts/private-data/collections_config.json \
#         --signature-policy "OR('vanguardMSP.member','jpmorganMSP.member')" \

approveForMyvanguard() {
    setGlobalsForPeer0vanguard
    sleep 10
    # set -x
    peer lifecycle chaincode approveformyorg -o orderer0-orderer:7050 --ordererTLSHostnameOverride orderer0-orderer --tls --cafile $ORDERER_CA --channelID $CHANNEL_NAME --name ${CC_NAME} --version ${VERSION} --init-required --package-id ${PACKAGE_ID} --sequence ${SEQUENCE}
    # set +x

    echo "===================== chaincode approved from org 1 ===================== "
    


}
# queryInstalled
# approveForMyvanguard

# --signature-policy "OR ('vanguardMSP.member')"
# --peerAddresses localhost:7051 --tlsRootCertFiles $PEER0_vanguard_CA --peerAddresses localhost:9051 --tlsRootCertFiles $PEER0_jpmorgan_CA
# --peerAddresses peer0.vanguard.:7051 --tlsRootCertFiles $PEER0_vanguard_CA --peerAddresses peer0.jpmorgan.:9051 --tlsRootCertFiles $PEER0_jpmorgan_CA
#--channel-config-policy Channel/Application/Admins
# --signature-policy "OR ('vanguardMSP.peer','jpmorganMSP.peer')"

checkCommitReadyness() {
    setGlobalsForPeer0vanguard
    sleep 5
    peer lifecycle chaincode checkcommitreadiness --channelID $CHANNEL_NAME \
        --peerAddresses peer0-vanguard:7051 --tlsRootCertFiles $PEER0_vanguard_CA \
        --name ${CC_NAME} --version ${VERSION} --sequence ${VERSION} --output json --init-required
    echo "===================== checking commit readyness from org 1 ===================== "
}

# checkCommitReadyness

approveForMyjpmorgan() {
    setGlobalsForPeer0jpmorgan
    sleep 5
    peer lifecycle chaincode approveformyorg -o orderer0-orderer:7050 --ordererTLSHostnameOverride orderer0-orderer --tls $CORE_PEER_TLS_ENABLED --cafile $ORDERER_CA --channelID $CHANNEL_NAME --name ${CC_NAME} --version ${VERSION} --init-required --package-id ${PACKAGE_ID} --sequence ${SEQUENCE}

    echo "===================== chaincode approved from org 2 ===================== "


}

# queryInstalled
# approveForMyjpmorgan

checkCommitReadyness() {

    setGlobalsForPeer0jpmorgan
    sleep 5
    peer lifecycle chaincode checkcommitreadiness --channelID $CHANNEL_NAME \
        --peerAddresses peer0-jpmorgan:7051 --tlsRootCertFiles $PEER0_jpmorgan_CA \
        --name ${CC_NAME} --version ${VERSION} --sequence ${VERSION} --output json --init-required
    echo "===================== checking commit readyness from org 2 ===================== "
}

approveForMystatestreet() {
    setGlobalsForPeer0statestreet
    sleep 5
    peer lifecycle chaincode approveformyorg -o orderer0-orderer:7050 --ordererTLSHostnameOverride orderer0-orderer --tls $CORE_PEER_TLS_ENABLED --cafile $ORDERER_CA --channelID $CHANNEL_NAME --name ${CC_NAME} --version ${VERSION} --init-required --package-id ${PACKAGE_ID} --sequence ${SEQUENCE}

    echo "===================== chaincode approved from org 2 ===================== "


}

# queryInstalled
# approveForMyjpmorgan

checkCommitReadyness() {

    setGlobalsForPeer0statestreet
    sleep 5
    peer lifecycle chaincode checkcommitreadiness --channelID $CHANNEL_NAME \
        --peerAddresses peer0-statestreet:7051 --tlsRootCertFiles $PEER0_statestreet_CA \
        --name ${CC_NAME} --version ${VERSION} --sequence ${VERSION} --output json --init-required
    echo "===================== checking commit readyness from org 2 ===================== "
}

# 
# checkCommitReadyness

commitChaincodeDefination() {
    setGlobalsForPeer0jpmorgan
    sleep 10
    peer lifecycle chaincode commit -o orderer0-orderer:7050 --ordererTLSHostnameOverride orderer0-orderer --tls $CORE_PEER_TLS_ENABLED --cafile $ORDERER_CA --channelID $CHANNEL_NAME --name ${CC_NAME} --peerAddresses peer0-vanguard:7051 --tlsRootCertFiles $PEER0_vanguard_CA --peerAddresses peer0-jpmorgan:7051 --tlsRootCertFiles $PEER0_jpmorgan_CA --peerAddresses peer0-statestreet:7051 --tlsRootCertFiles $PEER0_statestreet_CA --version ${VERSION} --sequence ${SEQUENCE} --init-required
sleep 1

}

# commitChaincodeDefination

queryCommitted() {
    setGlobalsForPeer0vanguard
    sleep 5
    peer lifecycle chaincode querycommitted --channelID $CHANNEL_NAME --name ${CC_NAME}

}
invoke(){
    setGlobalsForPeer0vanguard
    sleep 5
     peer chaincode invoke -o orderer0-orderer:7050 --ordererTLSHostnameOverride orderer0-orderer --tls true --cafile ${PWD}/artifacts/channel/crypto-config/ordererOrganizations/orderer/orderers/orderer0.orderer/msp/tlscacerts/tlsca.orderer-cert.pem -C vgchannel -n ${CC_NAME} --peerAddresses peer0-vanguard:7051 --tlsRootCertFiles ./artifacts/channel/crypto-config/peerOrganizations/vanguard/tlsca/tlsca.vanguard-cert.pem --peerAddresses peer0-jpmorgan:7051 --tlsRootCertFiles ./artifacts/channel/crypto-config/peerOrganizations/jpmorgan/tlsca/tlsca.jpmorgan-cert.pem --isInit -c '{"Args":["InitLedger"]}'
}
invoke2(){
setGlobalsForPeer0vanguard
 peer chaincode invoke -o orderer0-orderer:7050 --ordererTLSHostnameOverride orderer0-orderer --tls true --cafile ${PWD}/artifacts/channel/crypto-config/ordererOrganizations/orderer/orderers/orderer0.orderer/msp/tlscacerts/tlsca.orderer-cert.pem -C vgchannel -n ${CC_NAME} --peerAddresses peer0-vanguard:7051 --tlsRootCertFiles ./artifacts/channel/crypto-config/peerOrganizations/vanguard/tlsca/tlsca.vanguard-cert.pem --peerAddresses peer0-statestreet:7051 --tlsRootCertFiles ./artifacts/channel/crypto-config/peerOrganizations/statestreet/tlsca/tlsca.statestreet-cert.pem  -c '{"Args":["createCar","2","audi","r5","red","kartikey"]}'
}
#createCar
# queryCommitted


# chaincodeQuery

# Run this function if you add any new dependency in chaincode
# presetup

packageChaincode
sleep 10
installchaincodepeer0vanguard
sleep 5

installchaincodepeer0jpmorgan
sleep 10

installchaincodepeer0statestreet

sleep 10
queryInstalled
sleep 10
approveForMyvanguard
sleep 10

checkCommitReadyness
sleep 5
approveForMyjpmorgan
sleep 5
checkCommitReadyness
sleep 5
approveForMystatestreet
sleep 5
checkCommitReadyness
sleep 5
commitChaincodeDefination

sleep 5
queryCommitted
sleep 5

invoke
sleep 10

#sleep 2
#invoke2
