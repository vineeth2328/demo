#!/bin/sh

function one_line_pem {
    echo "`awk 'NF {sub(/\\n/, ""); printf "%s\\\\\\\n",$0;}' $1`"
}

function json_ccp {
    local PP=$(one_line_pem $4)
    local CP=$(one_line_pem $5)
   
    sed -e "s/\${ORG}/$1/" \
        -e "s/\${P0PORT}/$2/" \
        -e "s/\${CAPORT}/$3/" \
        -e "s#\${PEERPEM}#$PP#" \
        -e "s#\${CAPEM}#$CP#" \
        ./ccp-template.json
}

ORG=vanguard
P0PORT=7051
CAPORT=7054

PEERPEM=/opt/gopath/src/github.com/hyperledger/fabric/peer/artifacts/channel/crypto-config/peerOrganizations/vanguard/peers/peer0.vanguard/msp/tlscacerts/tlsca.vanguard-cert.pem

CAPEM=/opt/gopath/src/github.com/hyperledger/fabric/peer/artifacts/channel/crypto-config/peerOrganizations/vanguard/msp/tlscacerts/tlsca.vanguard-cert.pem

echo "$(json_ccp $ORG $P0PORT $CAPORT $PEERPEM $CAPEM $PEERPEM1 $P0PORT1)" > connection-vanguard.json


ORG=jpmorgan
P0PORT=7051
CAPORT=7054

PEERPEM=/opt/gopath/src/github.com/hyperledger/fabric/peer/artifacts/channel/crypto-config/peerOrganizations/jpmorgan/peers/peer0.jpmorgan/msp/tlscacerts/tlsca.jpmorgan-cert.pem

CAPEM=/opt/gopath/src/github.com/hyperledger/fabric/peer/artifacts/channel/crypto-config/peerOrganizations/jpmorgan/msp/tlscacerts/tlsca.jpmorgan-cert.pem


echo "$(json_ccp $ORG $P0PORT $CAPORT $PEERPEM $CAPEM $PEERPEM1 $P0PORT1)" > connection-jpmorgan.json


ORG=statestreet
P0PORT=7051
CAPORT=7054

PEERPEM=/opt/gopath/src/github.com/hyperledger/fabric/peer/artifacts/channel/crypto-config/peerOrganizations/statestreet/peers/peer0.statestreet/msp/tlscacerts/tlsca.statestreet-cert.pem

CAPEM=/opt/gopath/src/github.com/hyperledger/fabric/peer/artifacts/channel/crypto-config/peerOrganizations/statestreet/msp/tlscacerts/tlsca.statestreet-cert.pem


echo "$(json_ccp $ORG $P0PORT $CAPORT $PEERPEM $CAPEM $PEERPEM1 $P0PORT1)" > connection-statestreet.json
