'use strict';
const log4js = require('log4js');
const logger = log4js.getLogger('BasicNetwork');
const bodyParser = require('body-parser');

const http = require('http')
const util = require('util');
const exec = util.promisify(require('child_process').exec);
const express = require('express')
const app = express();
const test=express();
const expressJWT = require('express-jwt');
const jwt = require('jsonwebtoken');
const bearerToken = require('express-bearer-token');
const cors = require('cors');
const constants = require('./config/constants.json');
var _ = require('underscore');

const host = process.env.HOST || constants.host;
const port = process.env.PORT || constants.port;


const helper = require('./app/helper')
const invoke = require('./app/invoke')
const qscc = require('./app/qscc')
const query = require('./app/query');
const { chain } = require('underscore');

app.options('*', cors());
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: false
}));
// set secret variable
app.set('secret', 'thisismysecret');
app.use(expressJWT({
    secret: 'thisismysecret'
}).unless({
    path: ['/users','/users/login', '/register']
}));
app.use(bearerToken());

logger.level = 'debug';


app.use((req, res, next) => {
    logger.debug('New req for %s', req.originalUrl);
    if (req.originalUrl.indexOf('/users') >= 0 || req.originalUrl.indexOf('/users/login') >= 0 || req.originalUrl.indexOf('/register') >= 0) {
        return next();
    }
    var token = req.token;
    jwt.verify(token, app.get('secret'), (err, decoded) => {
        if (err) {
            console.log(`Error ================:${err}`)
            res.send({
                success: false,
                message: 'Failed to authenticate token. Make sure to include the ' +
                    'token returned from /users call in the authorization header ' +
                    ' as a Bearer token'
            });
            return;
        } else {
            req.username = decoded.username;
            req.orgname = decoded.orgName;
            logger.debug(util.format('Decoded from JWT token: username - %s, orgname - %s', decoded.username, decoded.orgName));
            return next();
        }
    });
});

var server = http.createServer(app).listen(port, function () { console.log(`Server started on ${port}`) });
logger.info('****************** SERVER STARTED ************************');
logger.info('***************  http://%s:%s  ******************', host, port);
server.timeout = 240000;

function getErrorMessage(field) {
    var response = {
        success: false,
        message: field + ' field is missing or Invalid in the request'
    };
    return response;
}

String.prototype.hashCode = function() {
    var hash = 0, i, chr;
    if (this.length === 0) return hash;
    for (i = 0; i < this.length; i++) {
      chr   = this.charCodeAt(i);
      hash  = ((hash << 5) - hash) + chr;
      hash |= 0;
    }
    return hash;
};

// Register and enroll user
app.post('/users', async function (req, res) {
    var username = req.body.username;
    var orgName = req.body.orgName;
    var userRole = req.body.userRole;
    logger.debug('End point : /users');
    logger.debug('User name : ' + username);
    logger.debug('Org name  : ' + orgName);
    if (!username) {
        res.json(getErrorMessage('\'username\''));
        return;
    }
    if (!orgName) {
        res.json(getErrorMessage('\'orgName\''));
        return;
    }
    if (!userRole) {
        res.json(getErrorMessage('\'userRole\''));
        return;
    }

    var token = jwt.sign({
        exp: Math.floor(Date.now() / 1000) + parseInt(constants.jwt_expiretime),
        username: username,
        orgName: orgName
    }, app.get('secret'));

    let response = await helper.getRegisteredUser(username, orgName, userRole, true);

    logger.debug('-- returned from registering the username %s for organization %s', username, orgName);
    if (response && typeof response !== 'string') {
        logger.debug('Successfully registered the username %s for organization %s', username, orgName);
        response.token = token;
        res.json(response);
    } else {
        logger.debug('Failed to register the username %s for organization %s with::%s', username, orgName, response);
        res.json({ success: false, message: response });
    }

});

// Register and enroll user
app.post('/register', async function (req, res) {
    var username = req.body.username;
    var orgName = req.body.orgName;
    logger.debug('End point : /users');
    logger.debug('User name : ' + username);
    logger.debug('Org name  : ' + orgName);
    if (!username) {
        res.json(getErrorMessage('\'username\''));
        return;
    }
    if (!orgName) {
        res.json(getErrorMessage('\'orgName\''));
        return;
    }

    var token = jwt.sign({
        exp: Math.floor(Date.now() / 1000) + parseInt(constants.jwt_expiretime),
        username: username,
        orgName: orgName
    }, app.get('secret'));

    console.log(token)

    let response = await helper.registerAndGerSecret(username, orgName);

    logger.debug('-- returned from registering the username %s for organization %s', username, orgName);
    if (response && typeof response !== 'string') {
        logger.debug('Successfully registered the username %s for organization %s', username, orgName);
        response.token = token;
        res.json(response);
    } else {
        logger.debug('Failed to register the username %s for organization %s with::%s', username, orgName, response);
        res.json({ success: false, message: response });
    }

});

// Login and get jwt
app.post('/users/login', async function (req, res) {
    try{
    var username = req.body.username;
    var orgName = req.body.orgName;
    logger.debug('End point : /users');
    logger.debug('User name : ' + username);
    logger.debug('Org name  : ' + orgName);
    if (!username) {
        res.json(getErrorMessage('\'username\''));
        return;
    }
    if (!orgName) {
        res.json(getErrorMessage('\'orgName\''));
        return;
    }

    var token = jwt.sign({
        exp: Math.floor(Date.now() / 1000) + parseInt(constants.jwt_expiretime),
        username: username,
        orgName: orgName
    }, app.get('secret'));

    let isUserRegistered = await helper.isUserRegistered(username, orgName);

    if (isUserRegistered) {
        res.json({ success: true, message: { token: token } });

    } else {
        res.json({ success: false, message: `User with username ${username} is not registered with ${orgName}, Please register first.` });
        
    } } catch(error){
        res.json({ success: false, message: `Mismatched User credentials!`})
        //console.log(error)
    } 

});

// Invoke transaction for listing out stocks 
app.post('/addListings', async function (req, res) {
    try {
        logger.debug('==================== INVOKE ON CHAINCODE ==================');
        // var peers = req.body.peers;
        var chaincodeName = "vanguard_cc";
        var channelName = "vgchannel";
        var fcn = "addListings";

        if (!req.body.args) {
            res.json(getErrorMessage('\'args\''));
            return;
        }

        var listings = req.body.args;
        
        for (let listing of listings){
            let id = `${listing.Symbol}-${listing.FundType}`
            let obj = JSON.stringify({"Id": id, ...listing});
            await invoke.invokeTransaction(channelName, chaincodeName, fcn, obj, req.username, req.orgname);
        }

        const response_payload = {
            result: {success: true, message: `Successfully added ${listings.length} listings in the Stock Listing model`},
            error: null,
            errorData: null
        }
        res.send(response_payload);

    } catch (error) {
        const response_payload = {
            result: {success: false, message: error.message},
            error: error.name,
            errorData: error.message
        }
        res.send(response_payload)
    }
});

// Invoke transaction of trade order entry creation on chaincode
app.post('/createOrders', async function (req, res) {
    try {
        logger.debug('==================== INVOKE ON CHAINCODE ==================');
        //var peers = req.body.peers;
        var chaincodeName = "vanguard_cc";
        var channelName = "vgchannel";
        var fcn = "CreateOrdersForHolding";

        if (!req.body.args) {
            res.json(getErrorMessage('\'args\''));
            return;
        }
       
        var order = req.body.args;
        //let orderId = `${Math.floor(Math.random() * 90 + 10)}${order.tradeFor.symbol.hashCode() % 100}`
       // let orderId = `${Math.floor(Math.random()*90000) + 10000}`;
       let orderId = `${Math.floor(Date.now() + Math.random()*90) + 10000}`;
        var orderObj = {...order, orderID: orderId, userId: req.username, timestamp: new Date()};
        var args = JSON.stringify(orderObj);

        let message = await invoke.invokeTransaction(channelName, chaincodeName, fcn, args, req.username, req.orgname);
        //console.log(`message result is : ${message}`)
        let messageType = typeof(message)
        //console.log(messageType)

        let messageResp;
        messageType === 'object' ? messageResp = `Successfully submitted order no. ${orderId}` : messageResp = `User is not authorized to perform this transaction`

        const response_payload = {
            result: {success: true, message: messageResp},
            error: null,
            errorData: null
        }
        res.send(response_payload);

    } catch (error) {
        const response_payload = {
            result: {success: false, message: error.message},
            error: error.name,
            errorData: error.message
        }
        res.send(response_payload)
    }
});




// Invoke transaction of trade order entry creation on chaincode
app.post('/createBulkOrders', async function (req, res) {
    try {
        logger.debug('==================== INVOKE ON CHAINCODE ==================');
        // var peers = req.body.peers;
        var chaincodeName = "vanguard_cc";
        var channelName = "vgchannel";
        var fcn = "CreateOrdersForHolding";

        if (!req.body.args) {
            res.json(getErrorMessage('\'args\''));
            return;
        }
       
        var orders = req.body.args;

        for (const order of orders) {

            let listing = await query.query(channelName, chaincodeName, order.tradeFor, "getStockDetails", req.username, req.orgname);
            console.log("listing[0].Record.SecurityName")
            console.log(listing[0].Record.SecurityName)

            let tradeFor = {"symbol":order.tradeFor,"name":listing[0].Record.SecurityName, "tradeStatus": listing[0].Record.TradeStatus};
            //let orderId = `${Math.floor(Math.random() * 90 + 10)}${tradeFor.symbol.hashCode() % 100}`
            //let orderId = `${Math.floor(Math.random()*90000) + 10000}`
            let orderId = `${Math.floor(Date.now() + Math.random()*90) + 10000}`;
            var orderObj = {...order, orderID: orderId, tradeFor, userId: req.username, timestamp: new Date()};
            var args = JSON.stringify(orderObj);
            
            await invoke.invokeTransaction(channelName, chaincodeName, fcn, args, req.username, req.orgname);
        }

        const response_payload = {
            result: {success: true, message: `Successfully imported ${orders.length} orders`},
            error: null,
            errorData: null
        }
        res.send(response_payload);

    } catch (error) {
        const response_payload = {
            result: {success: false, message: error.message},
            error: error.name,
            errorData: error.message
        }
        res.send(response_payload)
    }
});

// Invoke transaction for adding positions
app.post('/addPositions', async function (req, res) {
    try {
        logger.debug('==================== INVOKE ON CHAINCODE ==================');
        // var peers = req.body.peers;
        var chaincodeName = "vanguard_cc";
        var channelName = "vgchannel";
        var fcn = "addNewPositions";

        if (!req.body.args) {
            res.json(getErrorMessage('\'args\''));
            return;
        }

        var positions = req.body.args;

        for (let position of positions){

            let id = `${position.SecurityID}-${position.SecurityID.hashCode() % 10000}-${position.FundType}`
            let obj = JSON.stringify({"Id": id, ...position});

            console.log(obj)

            await invoke.invokeTransaction(channelName, chaincodeName, fcn, obj, req.username, req.orgname);
        }

        const response_payload = {
            result: {success: true, message: `Successfully imported ${positions.length} Positions`},
            error: null,
            errorData: null
        }
        res.send(response_payload);

    } catch (error) {
        const response_payload = {
            result: {success: false, message: error.message},
            error: error.name,
            errorData: error.message
        }
        res.send(response_payload)
    }
});

// // Add order allocations in respective funds
// app.post('/addAllocations', async function (req, res) {
//     try {
//         logger.debug('==================== INVOKE ON CHAINCODE ==================');
//         //var peers = req.body.peers;
//         var chaincodeName = "vanguard_cc";
//         var channelName = "vgchannel";
//         var fcn = "AddAllocationsInfo";
//         var allocations = req.body.args;

//         var args = [];
//         args[0] = allocations.orderId;
//         args[1] = JSON.stringify(allocations.allocinfo.allocVTI);
//         args[2] = JSON.stringify(allocations.allocinfo.allocVFINX);

//         logger.debug('channelName  : ' + channelName);
//         logger.debug('chaincodeName : ' + chaincodeName);
//         logger.debug('fcn  : ' + fcn);
//         logger.debug('args  : ' + args);
        
//         if (!args) {
//             res.json(getErrorMessage('\'args\''));
//             return;
//         }

//         let message = await invoke.invokeTransaction(channelName, chaincodeName, fcn, args, req.username, req.orgname);

//         let secId =  message.result.SecId;

//         let listing = await query.query(channelName, chaincodeName, secId, "getAvgStockPrice", req.username, req.orgname);

//         let avgCost = listing[0].Record.AvgCost;
//         let price = listing[0].Record.MarketPrice;
//         let idVTI = `${secId}-${secId.hashCode() % 10000}-VTI`

//         let objVTI = JSON.stringify({"Id": idVTI, "orderId": allocations.orderId, "fundType": "VTI", "allocId": allocations.allocinfo.allocVTI.Id, "cost": avgCost, "price": price});

//         let VTIresp = await invoke.invokeTransaction(channelName, chaincodeName, "createPositions", objVTI, req.username, req.orgname);
//         //console.log(`Allocated VTI successfully`)

//         console.log(VTIresp)

//         let idVFINX = `${secId}-${secId.hashCode() % 10000}-VFINX`

//         let objVFINX = JSON.stringify({"Id": idVFINX, "orderId": allocations.orderId, "fundType": "VFINX", "allocId": allocations.allocinfo.allocVFINX.Id, "cost": avgCost, "price": price});

//         let VFINXresp = await invoke.invokeTransaction(channelName, chaincodeName, "createPositions", objVFINX, req.username, req.orgname);
//         //console.log(`Allocated VFINX successfully`)
//         console.log(VFINXresp)

//         const response_payload = {
//             result: message,
//             avgCost: avgCost,
//             error: null,
//             errorData: null
//         }
//         res.send(response_payload);

//     } catch (error) {
//         const response_payload = {
//             result: null,
//             error: error.name,
//             errorData: error.message
//         }
//         res.send(response_payload)
//     }
// });

// Add order allocations in respective funds

app.post('/addAllocations', async function (req, res) {
    try {
        logger.debug('==================== INVOKE ON CHAINCODE ==================');
        //var peers = req.body.peers;
        var chaincodeName = "vanguard_cc";
        var channelName = "vgchannel";
        var fcn = "AddAllocationsInfo";
        var allocations = req.body.args;

        var args = [];
        args[0] = allocations.orderId;
        args[1] = req.username;
        args[3] = JSON.stringify(allocations.allocinfo);
        args[2] = JSON.stringify(new Date());

        logger.debug('channelName  : ' + channelName);
        logger.debug('chaincodeName : ' + chaincodeName);
        logger.debug('fcn  : ' + fcn);
        logger.debug('args  : ' + args);
        
        if (!args) {
            res.json(getErrorMessage('\'args\''));
            return;
        }
        console.log("args:",args)

        let message = await invoke.invokeTransaction(channelName, chaincodeName, fcn, args, req.username, req.orgname);

        var secId =  message.result.SecId;
       
        var positions = allocations.allocinfo;
        console.log("positions",positions)
        for (let i in positions){

            let id = `${secId}-${positions[i].fundType}`
            console.log("id",id)
            let listing = await query.query(channelName, "vanguard_cc", id, "ReadAsset", req.username, req.orgname);

            let avgCost = listing.AvgCost;
            let price = listing.MarketPrice;

            let Tid = `${secId}-${secId.hashCode() % 10000}-${positions[i].fundType}`

            let obj = JSON.stringify({"Id": Tid, "orderId": allocations.orderId, "fundType": positions[i].fundType, "allocId": i, "cost": avgCost, "price": price});

            await invoke.invokeTransaction(channelName, "vanguard_cc", "createPositions", obj, req.username, req.orgname);
        }

        const response_payload = {
            result: {success: true, message:  `Successfully updated allocation details on order no. ${args[0]}`},
            error: null,
            errorData: null
        }
        res.send(response_payload);

    } catch (error) {
        const response_payload = {
            result: {success: false, message: error.message},
            error: error.name,
            errorData: error.message
        }
        res.send(response_payload)
    }
});

app.get('/getOrderDetails/:orderId', async function (req, res) {
    try {
        logger.debug('==================== QUERY BY CHAINCODE ==================');

        var channelName = "vgchannel";
        var chaincodeName = "vanguard_cc";
        
        //let orderId = req.body.orderId;
        let fcn = "ReadAsset";
        var args = req.params.orderId;

        if (!chaincodeName) {
            res.json(getErrorMessage('\'chaincodeName\''));
            return;
        }
        if (!channelName) {
            res.json(getErrorMessage('\'channelName\''));
            return;
        }
        if (!fcn) {
            res.json(getErrorMessage('\'fcn\''));
            return;
        }
        if (!args) {
            res.json(getErrorMessage('\'args\''));
            return;
        }

        let message = await query.query(channelName, chaincodeName, args, fcn, req.username, req.orgname);

        const response_payload = {
            result: message,
            error: null,
            errorData: null
        }

        res.send(response_payload);
    } catch (error) {
        const response_payload = {
            result: null,
            error: error.name,
            errorData: error.message
        }
        res.send(response_payload)
    }
});

app.get('/getVTIpositions', async function (req, res) {
    try {
        logger.debug('==================== QUERY BY CHAINCODE ==================');

        var channelName = "vgchannel";
        var chaincodeName = "vanguard_cc";
        
        let args = "VTI";
        let fcn = "QueryHoldingsByFundType";
        let peer = "peer0.org1.example.com";

        logger.debug('channelName : ' + channelName);
        logger.debug('chaincodeName : ' + chaincodeName);
        logger.debug('fcn : ' + fcn);
        logger.debug('args : ' + args);

        if (!chaincodeName) {
            res.json(getErrorMessage('\'chaincodeName\''));
            return;
        }
        if (!channelName) {
            res.json(getErrorMessage('\'channelName\''));
            return;
        }
        if (!fcn) {
            res.json(getErrorMessage('\'fcn\''));
            return;
        }
        if (!args) {
            res.json(getErrorMessage('\'args\''));
            return;
        }
    
        let message = await query.query(channelName, chaincodeName, args, fcn, req.username, req.orgname);

        const response_payload = {
            result: message,
            error: null,
            errorData: null
        }

        res.send(response_payload);
    } catch (error) {
        const response_payload = {
            result: null,
            error: error.name,
            errorData: error.message
        }
        res.send(response_payload)
    }
});

app.get('/getVFINXpositions', async function (req, res) {
    try {
        logger.debug('==================== QUERY BY CHAINCODE ==================');

        var channelName = "vgchannel";
        var chaincodeName = "vanguard_cc";
        
        let args = "VFINX";
        let fcn = "QueryHoldingsByFundType";

        logger.debug('channelName : ' + channelName);
        logger.debug('chaincodeName : ' + chaincodeName);
        logger.debug('fcn : ' + fcn);
        logger.debug('args : ' + args);

        if (!chaincodeName) {
            res.json(getErrorMessage('\'chaincodeName\''));
            return;
        }
        if (!channelName) {
            res.json(getErrorMessage('\'channelName\''));
            return;
        }
        if (!fcn) {
            res.json(getErrorMessage('\'fcn\''));
            return;
        }
        if (!args) {
            res.json(getErrorMessage('\'args\''));
            return;
        }

        let message = await query.query(channelName, chaincodeName, args, fcn, req.username, req.orgname);

        const response_payload = {
            result: message,
            error: null,
            errorData: null
        }

        res.send(response_payload);
    } catch (error) {
        const response_payload = {
            result: null,
            error: error.name,
            errorData: error.message
        }
        res.send(response_payload)
    }
});

app.get('/listOrders', async function (req, res) {
    try {
        logger.debug('==================== QUERY BY CHAINCODE ==================');

        var channelName = "vgchannel";
        var chaincodeName = "vanguard_cc";
        
        let fcn = "ListMarketOrders";
        let args = "";

        if (!chaincodeName) {
            res.json(getErrorMessage('\'chaincodeName\''));
            return;
        }
        if (!channelName) {
            res.json(getErrorMessage('\'channelName\''));
            return;
        }
        if (!fcn) {
            res.json(getErrorMessage('\'fcn\''));
            return;
        }

        let message = await query.query(channelName, chaincodeName, args, fcn, req.username, req.orgname);

        const response_payload = {
            result: message,
            error: null,
            errorData: null
        }

        res.send(response_payload);
    } catch (error) {
        const response_payload = {
            result: null,
            error: error.name,
            errorData: error.message
        }
        res.send(response_payload)
    }
});

app.get('/getListedStocks', async function (req, res) {
    try {
        logger.debug('==================== QUERY BY CHAINCODE ==================');

        var channelName = "vgchannel";
        var chaincodeName = "vanguard_cc";
        
//

        let args = "";
        let fcn = "getListedStocks";
        let peer = req.query.peer;

        logger.debug('channelName : ' + channelName);
        logger.debug('chaincodeName : ' + chaincodeName);
        logger.debug('fcn : ' + fcn);
        

        if (!chaincodeName) {
            res.json(getErrorMessage('\'chaincodeName\''));
            return;
        }
        if (!channelName) {
            res.json(getErrorMessage('\'channelName\''));
            return;
        }
        if (!fcn) {
            res.json(getErrorMessage('\'fcn\''));
            return;
        }
        // if (!args) {
        //     res.json(getErrorMessage('\'args\''));
        //     return;
        // }
        // console.log('args==========', args);
        // args = args.replace(/'/g, '"');
        // args = JSON.parse(args);
        // logger.debug(args);

        let message = await query.query(channelName, chaincodeName, args, fcn, req.username, req.orgname);

        let listedStocks = [];

        for (const stock of message) {
            let stocksList = { 
                symbol : stock.Record.Symbol,
                name :stock.Record.SecurityName,
                tradeStatus : stock.Record.TradeStatus
            };
            
            if (_.findWhere(listedStocks, stocksList) == null) {
                listedStocks.push(stocksList);
            }
        }

        const response_payload = {
            result: listedStocks,
            error: null,
            errorData: null
        }

        res.send(response_payload);
    } catch (error) {
        const response_payload = {
            result: null,
            error: error.name,
            errorData: error.message
        }
        res.send(response_payload)
    }
});

// app.get('/qscc/channels/:channelName/chaincodes/:chaincodeName', async function (req, res) {
//     try {
//         logger.debug('==================== QUERY BY CHAINCODE ==================');

//         var channelName = req.params.channelName;
//         var chaincodeName = req.params.chaincodeName;
//         console.log(`chaincode name is :${chaincodeName}`)
//         let args = req.query.args;
//         let fcn = req.query.fcn;
//         // let peer = req.query.peer;

//         logger.debug('channelName : ' + channelName);
//         logger.debug('chaincodeName : ' + chaincodeName);
//         logger.debug('fcn : ' + fcn);
//         logger.debug('args : ' + args);

//         if (!chaincodeName) {
//             res.json(getErrorMessage('\'chaincodeName\''));
//             return;
//         }
//         if (!channelName) {
//             res.json(getErrorMessage('\'channelName\''));
//             return;
//         }
//         if (!fcn) {
//             res.json(getErrorMessage('\'fcn\''));
//             return;
//         }
//         if (!args) {
//             res.json(getErrorMessage('\'args\''));
//             return;
//         }
//         console.log('args==========', args);
//         args = args.replace(/'/g, '"');
//         args = JSON.parse(args);
//         logger.debug(args);

//         let response_payload = await qscc.qscc(channelName, chaincodeName, args, fcn, req.username, req.orgname);

//         // const response_payload = {
//         //     result: message,
//         //     error: null,
//         //     errorData: null
//         // }

//         res.send(response_payload);
//     } catch (error) {
//         const response_payload = {
//             result: null,
//             error: error.name,
//             errorData: error.message
//         }
//         res.send(response_payload)
//     }
// });

app.get("/getpods", async (req,res)=>{
    try {
    console.log("2222")
      var stdout = await exec("sh test4.sh");
    //console.log(stdout)
     const test = stdout.stdout.split(/\t?\n/);
     console.log(test)
    res.send(test)
       //console.log(data)
    }catch (error){
        res.send(error)
    }
    })

app.post("/deletepod",async(req,res)=>{
    const id = req.body.id;
    const command= "kubectl delete deploy "+ id;
    var stdout = await exec(command);
    
   res.send(stdout);
   console.log(stdout)
})    

app.post("/backup",async(req,res)=>{
    try{
    const id = req.body.id;
    const command= "kubectl apply -f "+ id + "/"
    console.log("@@@@@",command)
    var stdout = await exec(command);
   res.send(stdout);
   console.log(stdout)
    }catch(error){
        res.send(error)
    }
}) 

app.post("/getBlockHeight", async (req,res)=>{
    try{
    var stdout
    if(req.body.org=="statestreet")   {
        stdout = await exec("sh test.sh");
    } 
    else if (req.body.org=="vanguard"){
        stdout = await exec("sh test2.sh");
    }
    else if (req.body.org=="jpmorgan"){
        stdout = await exec("sh test3.sh");
    }
    console.log(stdout)
      
     const test = stdout.stdout.split(/\t?\n/);
     //console.log(test)
     var k  = test[0]
     var r = "kubectl exec -it "+ k + " -- peer channel getinfo --channelID vgchannel"
     //console.log(r)
     var y = await exec(r);
     //console.log(y)
     let output = y.stdout
     console.log(typeof(y.stdout))
     let response = output.replace("Blockchain info:", "");
     let respObj = JSON.parse(response)
     let height = respObj.height
     res.json(height)
}catch(error){
    res.send(error)
}
    })

app.get('/getBlock', async function (req, res) {
        try {
            logger.debug('==================== QUERY BY CHAINCODE ==================');
    
            var channelName = "vgchannel";
            var chaincodeName = "qscc";
            var args = [];
            args[0] = "";
    
            let fcn = "GetChainInfo";
    
            let response_payload = await qscc.qscc(channelName, chaincodeName, args, fcn, req.username, req.orgname);
    
            res.json(response_payload.low);
            
        } catch (error) {
            const response_payload = {
                result: null,
                error: error.name,
                errorData: error.message
            }
            res.send(response_payload)
        }
    });    



// Invoke transaction of trade order entry creation on chaincode
app.post('/importOrders', async function (req, res) {
    try {
        logger.debug('==================== INVOKE ON CHAINCODE ==================');
        //var peers = req.body.peers;
        var chaincodeName = "vanguard_cc15";
        var channelName = "mychannel";
        var fcn = "ImportOders";

        if (!req.body.args) {
            res.json(getErrorMessage('\'args\''));
            return;
        }
        console.log("working 1")
       console.log(req.body.args)
        var order = req.body.args;
        //let orderId = `${Math.floor(Math.random() * 90 + 10)}${order.tradeFor.symbol.hashCode() % 100}`
       // let orderId = `${Math.floor(Math.random()*90000) + 10000}`;
        var orderObj = {order, userId: req.username, timestamp: new Date()};
        var args = JSON.stringify(orderObj);
console.log("args",args)
        let message = await invoke.invokeTransaction(channelName, chaincodeName, fcn, args, req.username, req.orgname);
        //console.log(`message result is : ${message}`)
        let messageType = typeof(message)
        //console.log(messageType)

        let messageResp;
        messageType === 'object' ? messageResp = `Successfully imported ${order.length} Orders` : messageResp = `User is not authorized to perform this transaction`

        const response_payload = {
            result: {success: true, message: messageResp},
            error: null,
            errorData: null
        }
        res.send(response_payload);

    } catch (error) {
        const response_payload = {
            result: {success: false, message: error.message},
            error: error.name,
            errorData: error.message
        }
        res.send(response_payload)
    }
});

// ADD bulk allocations 


// app.post('/bulkAllocations', async function (req, res) {
//     try {
//         logger.debug('==================== INVOKE ON CHAINCODE ==================');
//         //var peers = req.body.peers;
//         var chaincodeName = "vanguard_cc15";
//         var channelName = "mychannel";
//         var fcn = "AddAllocationsInfo";
//         var orders = req.body.args;
// //console.log(orders)
//         for (const order of orders) {
//        console.log(order)
//         var args = [];
//         args[0] = order.orderId;
//         args[1] = req.username;
//         args[3] = JSON.stringify(order.allocinfo);
//         args[2] = JSON.stringify(new Date());

//         logger.debug('channelName  : ' + channelName);
//         logger.debug('chaincodeName : ' + chaincodeName);
//         logger.debug('fcn  : ' + fcn);
//         logger.debug('args  : ' + args);
        
//         if (!args) {
//             res.json(getErrorMessage('\'args\''));
//             return;
//         }

//         let message = await invoke.invokeTransaction(channelName, chaincodeName, fcn, args, req.username, req.orgname);

//         var secId =  message.result.SecId;
       
//         var positions = order.allocinfo;

//         for (let i in positions){

//             let id = `${secId}-${positions[i].fundType}`

//             let listing = await query.query(channelName, "vanguard_cc15", id, "ReadAsset", req.username, req.orgname);

//             let avgCost = listing.AvgCost;
//             let price = listing.MarketPrice;

//             let Tid = `${secId}-${secId.hashCode() % 10000}-${positions[i].fundType}`

//             let obj = JSON.stringify({"Id": Tid, "orderId": order.orderId, "fundType": positions[i].fundType, "allocId": i, "cost": avgCost, "price": price});

//             await invoke.invokeTransaction(channelName, "vanguard_cc15", "createPositions", obj, req.username, req.orgname);
//         }
//     }

//         const response_payload = {
//             result: {success: true, message:  `Successfully updated  bulkallocation details on order no. ${args[0]}`},
//             error: null,
//             errorData: null
//         }
//         res.send(response_payload);

//     } catch (error) {
//         const response_payload = {
//             result: {success: false, message: error.message},
//             error: error.name,
//             errorData: error.message
//         }
//         res.send(response_payload)
//     }
// });