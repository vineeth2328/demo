kubectl get po -o=jsonpath='{range .items[*]}{.metadata.name}{"\t"}{"\n"}{end}' | grep  peer0-jpmorgan
