/*
 * SPDX-License-Identifier: Apache-2.0
 */

'use strict';

const Holdings = require('./lib/holdings');

module.exports.Holdings = Holdings;
module.exports.contracts = [Holdings];